import java.sql.Date;

public class Cadastro {
	
    private int codigoAnimal;
    private char tipoAnimal;
    private String especie;
    private int idadeAnimal;
    private Date dataChegada;
    private String apelido;
    private char sexo;
    private String padraoCorPelo;
    private boolean filhote;
    private int qtdFilhotes;
	
	public Cadastro() {
		//M�todo construtor
	}
	
	public void listarAnimal() {
		//M�todo para listar os animais
		System.out.println("C�digo: " + codigoAnimal);
		System.out.println("Apelido: " + apelido);
		System.out.println("Esp�cie: " + especie);
	}

	public String Cadastrar(int codigoAnimal, char tipoAnimal, String especie, int idadeAnimal, Date dataChegada,
			String apelido, char sexo, String padraoCorPelo, boolean filhote, int qtdFilhotes) {
		//M�todo para cadastrar um animal
		this.codigoAnimal = codigoAnimal;
		this.tipoAnimal = tipoAnimal;
		this.especie = especie;
		this.idadeAnimal = idadeAnimal;
		this.dataChegada = dataChegada;
		this.apelido = apelido;
		this.sexo = sexo;
		this.padraoCorPelo = padraoCorPelo;
		this.filhote = filhote;
		this.qtdFilhotes = qtdFilhotes;
		return "Animal cadastrado!";
	}

	public int getCodigoAnimal() {
		return codigoAnimal;
	}

	public void setCodigoAnimal(int codigoAnimal) {
		this.codigoAnimal = codigoAnimal;
	}

	public char getTipoAnimal() {
		return tipoAnimal;
	}

	public void setTipoAnimal(char tipoAnimal) {
		this.tipoAnimal = tipoAnimal;
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public int getIdadeAnimal() {
		return idadeAnimal;
	}

	public void setIdadeAnimal(int idadeAnimal) {
		this.idadeAnimal = idadeAnimal;
	}

	public Date getDataChegada() {
		return dataChegada;
	}

	public void setDataChegada(Date dataChegada) {
		this.dataChegada = dataChegada;
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public String getPadraoCorPelo() {
		return padraoCorPelo;
	}

	public void setPadraoCorPelo(String padraoCorPelo) {
		this.padraoCorPelo = padraoCorPelo;
	}

	public boolean isFilhote() {
		return filhote;
	}

	public void setFilhote(boolean filhote) {
		this.filhote = filhote;
	}

	public int getQtdFilhotes() {
		return qtdFilhotes;
	}

	public void setQtdFilhotes(int qtdFilhotes) {
		this.qtdFilhotes = qtdFilhotes;
	}

	
	
	

}
