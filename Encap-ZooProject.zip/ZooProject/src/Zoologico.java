
public class Zoologico {

	public static void main(String[] args) {
		Cadastro cad = new Cadastro();
		cad.setApelido("Jo�o");
		cad.setCodigoAnimal(0);
		cad.setEspecie("Macaco");
		String apelido = cad.getApelido();
		System.out.println(apelido);
	}

}
