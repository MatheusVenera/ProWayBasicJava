package Construtor;

public class AlunoMain {

	public static void main(String[] args) {
		Aluno alu = new Aluno(10, 8, 6, 7);
		System.out.println(alu.calcularMedia());

	}

}
