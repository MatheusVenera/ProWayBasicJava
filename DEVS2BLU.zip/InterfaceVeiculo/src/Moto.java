
public class Moto implements Veiculo {
	
	double limiteVelocidade;
	String tipoCombustivel;
	double litragemTotal;
	String intensidadeFrenagem;


	public Moto(double limiteVelocidade, String tipoCombustivel, double litragemTotal, String intensidadeFrenagem) {
		super();
		this.limiteVelocidade = limiteVelocidade;
		this.tipoCombustivel = tipoCombustivel;
		this.litragemTotal = litragemTotal;
		this.intensidadeFrenagem = intensidadeFrenagem;
	}

	@Override
	public String Acelerar() {
		String retorno;
		retorno = "acelerando a " + this.limiteVelocidade;
		return retorno;
	}

	@Override
	public String Abastecer() {
		String retorno;
		retorno = "abastecendo os " + this.litragemTotal + " litros";
		return retorno;
	}

	@Override
	public String Frear() {
		String retorno;
		retorno = "freiando em " + this.intensidadeFrenagem + " frenagem";
		return retorno;
	}
}