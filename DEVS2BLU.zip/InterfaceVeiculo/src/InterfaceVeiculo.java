
public class InterfaceVeiculo {

	public static void main(String[] args) {
		Autom�vel carro = new Autom�vel(60.0, "Gasolina", 40.0, "Alta");
		System.out.println("O carro est� " + carro.Acelerar());
		System.out.println("O carro est� " + carro.Frear());
		System.out.println("O carro est� " + carro.Abastecer());
		
		
		Moto moto = new Moto(60.0, "Gasolina", 8.0, "Baixa");
		System.out.println("A moto est� " + moto.Acelerar());
		System.out.println("A moto est� " + moto.Frear());
		System.out.println("A moto est� " + moto.Abastecer());
	}

}
