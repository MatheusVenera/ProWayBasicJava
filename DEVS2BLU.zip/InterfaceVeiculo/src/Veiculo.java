
public interface Veiculo {
String Acelerar();
String Abastecer();
String Frear();
}
