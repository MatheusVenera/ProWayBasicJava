
public class InterfaceModelo {

	public static void main(String[] args) {
		
		Boi boi = new Boi();
		System.out.println("O boi fez " + boi.emitirSom() + " e comeu " + boi.tipoAlimento());
		

		Gato gato = new Gato();
		System.out.println("O gato fez " + gato.emitirSom() + " e comeu " + gato.tipoAlimento());

	}

}
