
public class Boi implements Animal {

	@Override
	public String emitirSom() {
		String som;
		som = "muuuu";
		return som;
	}

	@Override
	public String tipoAlimento() {
		String tipoAlimento;
		tipoAlimento = "capim";
		return tipoAlimento;
	}
		
	}


