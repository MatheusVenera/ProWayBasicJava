
public interface Animal {
public String emitirSom();
public String tipoAlimento();
}
