import java.util.Arrays;

import javax.swing.JOptionPane;

public class MeuArray {

	public static void main(String[] args) {
		int [] codigos = new int[10];
		String [] nomes = new String[10];
		double [] salarios = new double[10];
		for (int i = 0; i < codigos.length; i++) {
			Integer codigo = Integer.parseInt(JOptionPane.showInputDialog("Digite o c�digo da pessoa: "));
			codigos[i] = codigo;
			String nome = JOptionPane.showInputDialog("Digite o nome da pessoa: ");
			nomes[i] = nome;
			double salario = Double.parseDouble(JOptionPane.showInputDialog("Digite o sal�rio da pessoa: "));
			salarios[i] = salario;
			System.out.println("C�digo    Nome\n" + codigos[i] + "        " + nomes[i]);
		}
		double totalSalarios = 0;
		for (int i = 0; i < salarios.length; i++) {
			totalSalarios += salarios[i];
		}
		System.out.println("O total dos sal�rios �: " + totalSalarios);
		
		Arrays.sort(salarios);
		System.out.println("Os 3 maiores sal�rios s�o:\n1 - " + salarios[9] + "\n2 - " + salarios[8] + "\n3 - " + salarios[7]);
		
	}

}
