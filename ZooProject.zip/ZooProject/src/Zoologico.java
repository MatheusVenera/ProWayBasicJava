
public class Zoologico {

	public static void main(String[] args) {
		Cadastro cad = new Cadastro();
		cad.codigoAnimal = 1;
		cad.apelido = "Sim�o";
		cad.especie = "Macaco";
		cad.listarAnimal();
		
		cad.Cadastrar(1, 'M', "Le�o", 10, null, "Simba", 'M', "Laranja", false, 0);
	}

}
