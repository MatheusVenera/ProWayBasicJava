import java.sql.Date;

public class Cadastro {
	
	int codigoAnimal;
	char tipoAnimal;
	String especie;
	int idadeAnimal;
	Date dataChegada;
	String apelido;
	char sexo;
	String padraoCorPelo;
	boolean filhote;
	int qtdFilhotes;
	
	public Cadastro() {
		//M�todo construtor
	}
	
	public void listarAnimal() {
		//M�todo para listar os animais
		System.out.println("C�digo: " + codigoAnimal);
		System.out.println("Apelido: " + apelido);
		System.out.println("Esp�cie: " + especie);
	}

	public String Cadastrar(int codigoAnimal, char tipoAnimal, String especie, int idadeAnimal, Date dataChegada,
			String apelido, char sexo, String padraoCorPelo, boolean filhote, int qtdFilhotes) {
		//M�todo para cadastrar um animal
		this.codigoAnimal = codigoAnimal;
		this.tipoAnimal = tipoAnimal;
		this.especie = especie;
		this.idadeAnimal = idadeAnimal;
		this.dataChegada = dataChegada;
		this.apelido = apelido;
		this.sexo = sexo;
		this.padraoCorPelo = padraoCorPelo;
		this.filhote = filhote;
		this.qtdFilhotes = qtdFilhotes;
		return "Animal cadastrado!";
	}

	
	
	

}
