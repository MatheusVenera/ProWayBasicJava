
public class Funcionario {
	public String nome;
	public float salario;
	public int codDepto;
	public String descDepto;
	
	public void listarFuncionario() {
		System.out.println("Nome: " + nome);
		System.out.println("Sal�rio: " + salario);
	}
}
