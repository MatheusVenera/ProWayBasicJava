
public class Gerencia extends Funcionario {
	public float comissao;
	}

