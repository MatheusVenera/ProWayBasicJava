
public class Diretoria extends Presidente {
	public float rentabilidade;
	
}
