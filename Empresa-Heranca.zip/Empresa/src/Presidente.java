
public class Presidente extends Funcionario {
	public int nrAcionistas;

}
